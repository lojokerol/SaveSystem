// Author: DS_Long
// Publication: 2024-2-8


#include "X_Game_SaveSystem.h"

#include "GetComponentsToSaveByX_Game.h"
#include "X_GameCharacterSaveGame.h"
#include "Kismet/GameplayStatics.h"
#include "Serialization/ObjectAndNameAsStringProxyArchive.h"
#include "Serialization/MemoryReader.h"
#include "Serialization/MemoryWriter.h"

void UX_Game_SaveSystem::SaveObject(UObject* SaveObject, const FString SlotName, const bool IsObjectSaveGame, const bool IsChildObjectSaveGame)
{
	UX_GameCharacterSaveGame* SaveGameIns = Cast<UX_GameCharacterSaveGame>(UGameplayStatics::LoadGameFromSlot(SlotName,0));
	if(!SaveGameIns)
	{
		SaveGameIns = Cast<UX_GameCharacterSaveGame>(UGameplayStatics::CreateSaveGameObject(UX_GameCharacterSaveGame::StaticClass()));
	}
	const UX_GameCharacterSaveGame* SerialData = SerializeActor(SaveObject, IsObjectSaveGame, IsChildObjectSaveGame);
	if (SerialData)
	{
		SaveGameIns->PtrData = SerialData->PtrData;
		SaveGameIns->ComponentsData = SerialData->ComponentsData;
		UGameplayStatics::SaveGameToSlot(SaveGameIns,SlotName,0);
	}
}


UObject* UX_Game_SaveSystem::LoadObject(TArray<UObject*>& childObjects, UObject* LoadObject, FString SlotName, bool DeSerializeSelf, bool IsObjectSaveGame, bool IsChildObjectSaveGame)
{
	UX_GameCharacterSaveGame* SaveGameIns = Cast<UX_GameCharacterSaveGame>(UGameplayStatics::LoadGameFromSlot(SlotName, 0));
	if(!SaveGameIns) return nullptr;
	if(DeSerializeSelf)
	{
		FMemoryReader MemoryReader(SaveGameIns->PtrData, true);
		FObjectAndNameAsStringProxyArchive Ar(MemoryReader, false);
		Ar.ArIsSaveGame = IsObjectSaveGame;
		Ar.ArNoDelta = false;
		LoadObject->Serialize(Ar);
		DeserializeComponents(childObjects, LoadObject, SaveGameIns, IsChildObjectSaveGame, DeSerializeSelf);
		return LoadObject;
	}
	else
	{
		// UObject* NewActor = NewObject<UObject>(actor,actor->GetClass());
		UObject* NewActor = UGameplayStatics::SpawnObject(LoadObject->GetClass(),LoadObject);
		FMemoryReader MemoryReader(SaveGameIns->PtrData, true);
		FObjectAndNameAsStringProxyArchive Ar(MemoryReader, false);
		Ar.ArIsSaveGame = IsObjectSaveGame;
		Ar.ArNoDelta = false;
		NewActor->Serialize(Ar);
		DeserializeComponents(childObjects, NewActor, SaveGameIns, IsChildObjectSaveGame, DeSerializeSelf);
		return NewActor;
	}

}

UX_GameCharacterSaveGame* UX_Game_SaveSystem::SerializeActor(UObject* InObject, bool IsSaveGame, bool IsChildObjectSaveGame)
{
	UX_GameCharacterSaveGame* Record = NewObject<UX_GameCharacterSaveGame>();
	SerializeComponents(InObject, Record, IsChildObjectSaveGame);
	FMemoryWriter MemoryWriter(Record->PtrData, true);
	FObjectAndNameAsStringProxyArchive Ar(MemoryWriter, false);
	Ar.ArIsSaveGame = IsSaveGame;
	Ar.ArNoDelta = false;
	InObject->Serialize(Ar);
	return Record;
}

void UX_Game_SaveSystem::SerializeComponents(UObject* InObject, UX_GameCharacterSaveGame* SaveData, bool IsChildObjectSaveGame)
{
	if(!InObject) return;
	bool bImplements = InObject->GetClass()->ImplementsInterface(UGetComponentsToSaveByX_Game::StaticClass());
	if(!bImplements) return;
	 TArray<UObject*> Components = IGetComponentsToSaveByX_Game::Execute_GetChildObjects(InObject);
	if(Components.Num()>0)
	{
		for (auto Component : Components)
		{
			if(!Component) continue;
			FComponentData ComData;
			if(Component && Component->GetClass())
			{
				ComData.PtrClass = Component->GetClass();
				FMemoryWriter MemoryWriter(ComData.PtrData, true);
				FObjectAndNameAsStringProxyArchive Ar(MemoryWriter, false);
				Ar.ArIsSaveGame = IsChildObjectSaveGame;
				Ar.ArNoDelta = false;
				Component->Serialize(Ar);
				SaveData->ComponentsData.Add(ComData);
			}
		}
	}

}


void UX_Game_SaveSystem::DeserializeComponents(TArray<UObject*>& ChildObjects, UObject* actor, UX_GameCharacterSaveGame* SaveData, bool IsChildObjectSaveGame, bool DeSerializeSelfActor)
{
	if(DeSerializeSelfActor)
	{
		bool bImplements = actor->GetClass()->ImplementsInterface(UGetComponentsToSaveByX_Game::StaticClass());
		if(!bImplements) return;
		TArray<UObject*> Objects = IGetComponentsToSaveByX_Game::Execute_GetChildObjects(actor);
		if(Objects.Num()>0)
		{
			for (UObject* Obj : Objects)
			{
				if(Obj && Obj->GetClass())
				{
					const UClass* ComClass = Obj->GetClass();
					FComponentData* ComData = SaveData->ComponentsData.FindByKey(ComClass);
					if (ComData)
					{
						FMemoryReader MemoryReader(ComData->PtrData, true);
						FObjectAndNameAsStringProxyArchive Ar(MemoryReader, false);
						Ar.ArIsSaveGame = IsChildObjectSaveGame;
						Ar.ArNoDelta = false;
						Obj->Serialize(Ar);
					}
				}
			}
			ChildObjects = {};
		}
	}
	else
	{
		bool bImplements = actor->GetClass()->ImplementsInterface(UGetComponentsToSaveByX_Game::StaticClass());
		if(!bImplements) return;
		TArray<UObject* > Objects = IGetComponentsToSaveByX_Game::Execute_GetChildObjects(actor);
		if(Objects.Num()>0)
		{
			for (UObject* Obj : Objects)
			{
				if(!Obj) continue;
				UObject* NewObj = Cast<UObject>(UGameplayStatics::SpawnObject(Obj->GetClass(),actor));
				if(NewObj)
				{
					const UClass* ComClass = Obj->GetClass();
					FComponentData* ComData = SaveData->ComponentsData.FindByKey(ComClass);
					FMemoryReader MemoryReader(ComData->PtrData, true);
					FObjectAndNameAsStringProxyArchive Ar(MemoryReader, false);
					Ar.ArIsSaveGame = IsChildObjectSaveGame;
					Ar.ArNoDelta = false;
					NewObj->Serialize(Ar);
					ChildObjects.Add(NewObj);
				}
			}
		}
	}
}

