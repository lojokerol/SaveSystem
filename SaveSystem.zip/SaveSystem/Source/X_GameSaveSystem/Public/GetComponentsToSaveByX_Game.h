﻿// Author: DS_Long

#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "GetComponentsToSaveByX_Game.generated.h"

// This class does not need to be modified.
UINTERFACE(BlueprintType,Blueprintable)
class UGetComponentsToSaveByX_Game : public UInterface
{
	GENERATED_BODY()
};

/**
 * 
 */
class X_GAMESAVESYSTEM_API IGetComponentsToSaveByX_Game
{
	GENERATED_BODY()

	
public:
	/*接口：选择该对象下需要存储的对象*/
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category="X_GameSaveSystem")
	TArray<UObject*> GetChildObjects();
};
