﻿// Author: DS_Long
// Publication: 2024-2-8

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/SaveGame.h"
#include "X_GameCharacterSaveGame.generated.h"

USTRUCT()
struct FComponentData
{
	GENERATED_BODY()
	
	UPROPERTY(SaveGame)
	TArray<uint8> PtrData;

	UPROPERTY(SaveGame)
	UClass* PtrClass;

	FORCEINLINE bool operator==(const FComponentData& Other) const
	{
		return this->PtrClass == Other.PtrClass;
	}
	
	FORCEINLINE bool operator==(const UClass* Other) const
	{
		return this->PtrClass == Other;
	}
};

/**
 * A structure that stores data
 */
UCLASS()
class X_GAMESAVESYSTEM_API UX_GameCharacterSaveGame : public USaveGame
{
	GENERATED_BODY()

public:
	UPROPERTY(SaveGame)
	TArray<uint8> PtrData = {};

	UPROPERTY(SaveGame)
	TArray<FComponentData> ComponentsData = {};

};
