// Author: DS_Long
// Publication: 2024-2-8

#pragma once

#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "X_Game_SaveSystem.generated.h"

class UX_GameCharacterSaveGame;
/**
 * 
 */
UCLASS(Blueprintable,Blueprintable)
class X_GAMESAVESYSTEM_API UX_Game_SaveSystem : public UGameInstanceSubsystem
{
	GENERATED_BODY()

public:
	/*
	 * IsObjectSaveGame: 传入的UObject是否根据SaveGame标识符序列化数据
	 * IsChildObjectsSaveGame: 传入的在父UObject上的Objects是否通过SaveGame标识符存储
	 */
	UFUNCTION(BlueprintCallable, Category="X_GameSaveSystem")
	void SaveObject(UObject* SaveObject, const FString SlotName, const bool IsObjectSaveGame = false, const bool IsChildObjectsSaveGame = false);
	
	/* DeSerializeSelf: 是否直接修改传入Actor或返回一个新的Actor指针不会影响传入Actor*/
	UFUNCTION(BlueprintCallable, Category="X_GameSaveSystem")
	UObject* LoadObject(TArray<UObject*>& childObjects, UObject* LoadObject, FString SlotName, bool DeSerializeSelf = false, bool IsObjectSaveGame = false, bool IsChildObjectSaveGame = false);

	class UX_GameCharacterSaveGame* SerializeActor(UObject* InObject, bool IsSaveGame = false, bool IsChildObjectSaveGame = false);

	void SerializeComponents(UObject* InObject, UX_GameCharacterSaveGame* SaveData, bool IsChildObjectSaveGame = false);

	void DeserializeComponents(TArray<UObject*>& ChildObjects, UObject* actor, UX_GameCharacterSaveGame* SaveData, bool IsSaveGame = false, bool IsChildObjectSaveGame = false);

};
