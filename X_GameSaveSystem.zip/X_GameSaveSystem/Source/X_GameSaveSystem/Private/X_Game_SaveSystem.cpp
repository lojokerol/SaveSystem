// Fill out your copyright notice in the Description page of Project Settings.


#include "X_Game_SaveSystem.h"

#include "GetComponentsToSaveByX_Game.h"
#include "X_GameCharacterSaveGame.h"
#include "Kismet/GameplayStatics.h"
#include "Serialization/MemoryReader.h"
#include "Serialization/MemoryWriter.h"
#include "Serialization/ObjectAndNameAsStringProxyArchive.h"
#include "Serialization/ObjectWriter.h"
#include "UObject/UObjectGlobals.h"
#include "Serialization/ObjectAndNameAsStringProxyArchive.h"

void UX_Game_SaveSystem::SaveActor(UObject* actor, FString SlotName, bool IsSaveGame)
{
	UX_GameCharacterSaveGame* SaveGameIns = Cast<UX_GameCharacterSaveGame>(UGameplayStatics::LoadGameFromSlot(SlotName,0));
	if(!SaveGameIns)
	{
		SaveGameIns = Cast<UX_GameCharacterSaveGame>(UGameplayStatics::CreateSaveGameObject(UX_GameCharacterSaveGame::StaticClass()));
	}
	const UX_GameCharacterSaveGame* SerialData = SerializeActor(actor, IsSaveGame);
	SaveGameIns->PtrData = SerialData->PtrData;
	SaveGameIns->ComponentsData = SerialData->ComponentsData;
	UGameplayStatics::SaveGameToSlot(SaveGameIns,SlotName,0);
}


UObject* UX_Game_SaveSystem::LoadActor(TArray<UActorComponent*>& ActorComponents, UObject* actor, FString SlotName, bool DeSerializeSelfActor, bool IsSaveGame)
{
	UX_GameCharacterSaveGame* SaveGameIns = Cast<UX_GameCharacterSaveGame>(UGameplayStatics::LoadGameFromSlot(SlotName, 0));
	if(!SaveGameIns) return nullptr;
	if(DeSerializeSelfActor)
	{
		FMemoryReader MemoryReader(SaveGameIns->PtrData, true);
		FObjectAndNameAsStringProxyArchive Ar(MemoryReader, false);
		Ar.ArIsSaveGame = IsSaveGame;
		Ar.ArNoDelta = true;
		actor->Serialize(Ar);
		DeserializeComponents(ActorComponents, actor, SaveGameIns, IsSaveGame, DeSerializeSelfActor);
		return actor;
	}
	else
	{
		// UObject* NewActor = NewObject<UObject>(actor,actor->GetClass());
		UObject* NewActor = UGameplayStatics::SpawnObject(actor->GetClass(),actor);
		FMemoryReader MemoryReader(SaveGameIns->PtrData, true);
		FObjectAndNameAsStringProxyArchive Ar(MemoryReader, false);
		Ar.ArIsSaveGame = IsSaveGame;
		Ar.ArNoDelta = true;
		NewActor->Serialize(Ar);
		DeserializeComponents(ActorComponents, NewActor, SaveGameIns, IsSaveGame, DeSerializeSelfActor);
		return NewActor;
	}

}

UX_GameCharacterSaveGame* UX_Game_SaveSystem::SerializeActor(UObject* actor, bool IsSaveGame)
{
	UX_GameCharacterSaveGame* Record = NewObject<UX_GameCharacterSaveGame>();
	SerializeComponents(actor, Record,IsSaveGame);
	FMemoryWriter MemoryWriter(Record->PtrData, true);
	FObjectAndNameAsStringProxyArchive Ar(MemoryWriter, false);
	Ar.ArIsSaveGame = IsSaveGame;
	Ar.ArNoDelta = true;
	actor->Serialize(Ar);
	return Record;
}

void UX_Game_SaveSystem::SerializeComponents(UObject* actor, UX_GameCharacterSaveGame* SaveData, bool IsSaveGame)
{
	bool bImplements = actor->GetClass()->ImplementsInterface(UGetComponentsToSaveByX_Game::StaticClass());
	if(!bImplements) return;
	 TArray<UActorComponent*> Components = IGetComponentsToSaveByX_Game::Execute_GetComponents(actor);
	if(Components.Num()>0)
	{
		for (auto Component : Components)
		{
			FComponentData ComData;
			if(Component && Component->GetClass())
			{
				ComData.PtrClass = Component->GetClass();
				FMemoryWriter MemoryWriter(ComData.PtrData, true);
				FObjectAndNameAsStringProxyArchive Ar(MemoryWriter, false);
				Ar.ArIsSaveGame = IsSaveGame;
				Ar.ArNoDelta = true;
				Component->Serialize(Ar);
				SaveData->ComponentsData.Add(ComData);
			}
		}
	}

}


void UX_Game_SaveSystem::DeserializeComponents(TArray<UActorComponent*>& ActorComponents, UObject* actor, UX_GameCharacterSaveGame* SaveData, bool IsSaveGame,
	bool DeSerializeSelfActor)
{
	if(DeSerializeSelfActor)
	{
		bool bImplements = actor->GetClass()->ImplementsInterface(UGetComponentsToSaveByX_Game::StaticClass());
		if(!bImplements) return;
		TArray<UActorComponent*> Components = IGetComponentsToSaveByX_Game::Execute_GetComponents(actor);
		if(Components.Num()>0)
		{
			for (UActorComponent* Component : Components)
			{
				if(Component && Component->GetClass())
				{
					const UClass* ComClass = Component->GetClass();
					FComponentData* ComData = SaveData->ComponentsData.FindByKey(ComClass);
					FMemoryReader MemoryReader(ComData->PtrData, true);
					FObjectAndNameAsStringProxyArchive Ar(MemoryReader, false);
					Ar.ArIsSaveGame = IsSaveGame;
					Ar.ArNoDelta = true;
					Component->Serialize(Ar);
				}
			}
			ActorComponents = {};
		}
	}
	else
	{
		bool bImplements = actor->GetClass()->ImplementsInterface(UGetComponentsToSaveByX_Game::StaticClass());
		if(!bImplements) return;
		TArray<UActorComponent*> Components = IGetComponentsToSaveByX_Game::Execute_GetComponents(actor);
		if(Components.Num()>0)
		{
			for (UActorComponent* Component : Components)
			{
				UActorComponent* NewCom = Cast<UActorComponent>(UGameplayStatics::SpawnObject(Component->GetClass(),actor));
				if(NewCom)
				{
					const UClass* ComClass = Component->GetClass();
					FComponentData* ComData = SaveData->ComponentsData.FindByKey(ComClass);
					FMemoryReader MemoryReader(ComData->PtrData, true);
					FObjectAndNameAsStringProxyArchive Ar(MemoryReader, false);
					Ar.ArIsSaveGame = IsSaveGame;
					Ar.ArNoDelta = true;
					NewCom->Serialize(Ar);
					ActorComponents.Add(NewCom);
				}
			}
		}
	}
}

