﻿// 深圳市灵境互娱科技有限公司

#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "GetComponentsToSaveByX_Game.generated.h"

// This class does not need to be modified.
UINTERFACE(BlueprintType,Blueprintable)
class UGetComponentsToSaveByX_Game : public UInterface
{
	GENERATED_BODY()
};

/**
 * 
 */
class X_GAMESAVESYSTEM_API IGetComponentsToSaveByX_Game
{
	GENERATED_BODY()

	// Add interface functions to this class. This is the class that will be inherited to implement this interface.
public:
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category="SaveSystem")
	TArray<UActorComponent*> GetComponents();
};
