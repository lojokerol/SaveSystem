// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "X_Game_SaveSystem.generated.h"

class UX_GameCharacterSaveGame;
/**
 * 
 */
UCLASS(Blueprintable,Blueprintable)
class X_GAMESAVESYSTEM_API UX_Game_SaveSystem : public UGameInstanceSubsystem
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category="SaveSystem")
	void SaveActor(UObject* actor, FString SlotName, bool IsSaveGame = false);
	
	/*
	 @param DeSerializeSelfActor Whether to modify the incoming Actor directly or return a new Actor pointer does not affect the incoming Actor
	 */
	UFUNCTION(BlueprintCallable, Category="SaveSystem")
	UObject* LoadActor(TArray<UActorComponent*>& ActorComponents, UObject* actor,FString SlotName, bool DeSerializeSelfActor = false, bool IsSaveGame = false);

	class UX_GameCharacterSaveGame* SerializeActor(UObject* actor, bool IsSaveGame = false);

	void SerializeComponents(UObject* actor, UX_GameCharacterSaveGame* SaveData, bool IsSaveGame = false);

	void DeserializeComponents(TArray<UActorComponent*>& ActorComponents, UObject* actor, UX_GameCharacterSaveGame* SaveData, bool IsSaveGame = false, bool DeSerializeSelfActor = false);

	
};
